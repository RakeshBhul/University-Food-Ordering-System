package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;
import models.Customer;
import models.MenuItem;
import services.OrderService;
import services.PaymentService;
import services.NotificationSystem;
import services.UserService;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import models.Order;
import models.Transaction;

public class CustomerView extends JFrame {
    private Customer customer;
    private OrderService orderService;
    private PaymentService paymentService;
    private NotificationSystem notificationSystem;
    private JPanel menuPanel;
    private UserService userService;
    private JLabel totalLabel;
    private double currentOrderTotal = 0.0;
    private JFrame previousWindow;

    public CustomerView(JFrame previousWindow, Customer customer, UserService userService) {
        this.previousWindow = previousWindow;
        this.customer = customer;
        this.userService = userService;
        this.orderService = new OrderService(userService);
        this.paymentService = new PaymentService(userService);
        this.notificationSystem = new NotificationSystem(userService);

        // Load credit from file
        double savedCredit = userService.loadCreditFromFile(customer);
        customer.setCredit(savedCredit);

        setTitle("Customer Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Set background color
        getContentPane().setBackground(new Color(0xF5F5F5)); // Light grey

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(0xFFFFFF)); // White

        JLabel titleLabel = new JLabel("Customer Dashboard", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setForeground(new Color(0x007FFF)); // Light Blue
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        topPanel.add(titleLabel, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(0xDC3545)); // Red
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                previousWindow.setVisible(true); // Show the previous window
            }
        });
        backButton.setPreferredSize(new Dimension(100, 40));
        topPanel.add(backButton, BorderLayout.WEST);

        add(topPanel, BorderLayout.NORTH);

        menuPanel = new JPanel(new GridBagLayout());
        menuPanel.setBackground(new Color(0xFFFFFF)); // White
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(new JScrollPane(menuPanel), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(new Color(0xFFFFFF)); // White
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        totalLabel = new JLabel("Total Credit: $" + customer.getCredit(), SwingConstants.CENTER);
        totalLabel.setFont(new Font("Arial", Font.BOLD, 20));
        totalLabel.setForeground(new Color(0x28A745)); // Green
        bottomPanel.add(totalLabel, BorderLayout.CENTER);

        JButton topUpButton = new JButton("Top-Up Credit");
        topUpButton.setFont(new Font("Arial", Font.BOLD, 14));
        topUpButton.setForeground(Color.WHITE);
        topUpButton.setBackground(new Color(0x17a2b8)); // Cyan
        topUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                topUpCredit();
            }
        });
        bottomPanel.add(topUpButton, BorderLayout.EAST);

        add(bottomPanel, BorderLayout.SOUTH);

        // Add buttons for Order and Transaction history
        JPanel historyButtonPanel = new JPanel(new FlowLayout());
        JButton orderHistoryButton = new JButton("Order History");
        orderHistoryButton.setFont(new Font("Arial", Font.BOLD, 14));
        orderHistoryButton.setForeground(Color.WHITE);
        orderHistoryButton.setBackground(new Color(0x007FFF)); // Light Blue

        JButton transactionHistoryButton = new JButton("Transaction History");
        transactionHistoryButton.setFont(new Font("Arial", Font.BOLD, 14));
        transactionHistoryButton.setForeground(Color.WHITE);
        transactionHistoryButton.setBackground(new Color(0x007FFF)); // Light Blue

        historyButtonPanel.add(orderHistoryButton);
        historyButtonPanel.add(transactionHistoryButton);
        topPanel.add(historyButtonPanel, BorderLayout.SOUTH);

        orderHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showOrderHistory();
            }
        });

        transactionHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showTransactionHistory();
            }
        });

        refreshMenuItems();

        setPreferredSize(new Dimension(1000, 800));
        pack();
        setLocationRelativeTo(null);
        setResizable(true);
    }

    private void refreshMenuItems() {
        menuPanel.removeAll();
        List<MenuItem> menuItems = userService.getAllMenuItems();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 0.5;
        gbc.weighty = 1;

        int col = 0;

        for (MenuItem menuItem : menuItems) {
            JPanel itemPanel = new JPanel(new BorderLayout());
            itemPanel.setBackground(new Color(0xFFFFFF)); // White background
            itemPanel.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0), 1));
            itemPanel.setPreferredSize(new Dimension(300, 400)); // Set preferred size for the item panel

            JLabel itemLabel = new JLabel(menuItem.getName() + " - $" + menuItem.getPrice(), SwingConstants.CENTER);
            itemLabel.setFont(new Font("Arial", Font.BOLD, 16));
            itemPanel.add(itemLabel, BorderLayout.NORTH);

            ImageIcon imageIcon = loadImageIcon(menuItem.getImagePath(), 200, 200); // Resize image to fit the space
            JLabel imageLabel = new JLabel(imageIcon);
            imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
            itemPanel.add(imageLabel, BorderLayout.CENTER);

            JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 10)); // Panel for buttons

            JButton orderButton = new JButton("Order");
            orderButton.setFont(new Font("Arial", Font.BOLD, 14));
            orderButton.setForeground(Color.WHITE);
            orderButton.setBackground(new Color(0x28A745)); // Green
            orderButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    placeOrder(menuItem);
                }
            });
            buttonPanel.add(orderButton);

            JButton cancelButton = new JButton("Cancel");
            cancelButton.setFont(new Font("Arial", Font.BOLD, 14));
            cancelButton.setForeground(Color.WHITE);
            cancelButton.setBackground(new Color(0xDC3545)); // Red
            cancelButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cancelOrder(menuItem);
                }
            });
            buttonPanel.add(cancelButton);

            itemPanel.add(buttonPanel, BorderLayout.SOUTH);

            gbc.gridx = col % 2;
            gbc.gridy = col / 2;
            menuPanel.add(itemPanel, gbc);
            col++;
        }

        menuPanel.revalidate();
        menuPanel.repaint();
    }

    private ImageIcon loadImageIcon(String path, int width, int height) {
        try {
            BufferedImage img = ImageIO.read(new File(path));
            Image scaledImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            return new ImageIcon(scaledImg);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void placeOrder(MenuItem menuItem) {
    int response = JOptionPane.showConfirmDialog(this, "Order: " + menuItem.getName() + " for $" + menuItem.getPrice() + "?", "Confirm Order", JOptionPane.YES_NO_OPTION);
    if (response == JOptionPane.YES_OPTION) {
        boolean orderSuccess = orderService.placeOrder(customer, menuItem);
        if (orderSuccess) {
            JOptionPane.showMessageDialog(this, "Ordered: " + menuItem.getName());
            customer.setCredit(customer.getCredit() - menuItem.getPrice());
            userService.topUpCredit(customer, 0); // Update the credit in the text file
            refreshTotalLabel(); // Update total credit label
            notificationSystem.notifyDeliveryRunner(menuItem); // Notify the delivery runner
        } else {
            JOptionPane.showMessageDialog(this, "Failed to place order. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
    private void cancelOrder(MenuItem menuItem) {
        int response = JOptionPane.showConfirmDialog(this, "Cancel order for: " + menuItem.getName() + "?", "Cancel Order", JOptionPane.YES_NO_OPTION);
                if (response == JOptionPane.YES_OPTION) {
            boolean cancelSuccess = orderService.cancelOrder(customer, menuItem);
            if (cancelSuccess) {
                JOptionPane.showMessageDialog(this, "Cancelled: " + menuItem.getName());
                customer.setCredit(customer.getCredit() + menuItem.getPrice());
                userService.topUpCredit(customer, 0); // Update the credit in the text file
                refreshTotalLabel(); // Update total credit label
            } else {
                JOptionPane.showMessageDialog(this, "Failed to cancel order. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showOrderHistory() {
        List<Order> orders = orderService.getOrdersByCustomer(customer);
        String[] columnNames = {"MenuItem", "Price", "Date"};
        Object[][] data = new Object[orders.size()][3];

        for (int i = 0; i < orders.size(); i++) {
            Order order = orders.get(i);
            data[i][0] = order.getMenuItem().getName();
            data[i][1] = "$" + order.getMenuItem().getPrice();
            data[i][2] = order.getOrderDate();
        }

        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);
        JOptionPane.showMessageDialog(this, scrollPane, "Order History", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showTransactionHistory() {
        List<Transaction> transactionHistory = orderService.getTransactionHistoryByCustomer(customer);
        Object[][] data = new Object[transactionHistory.size()][4];
        double totalCost = orderService.calculateTotalCostByCustomer(customer);

        for (int i = 0; i < transactionHistory.size(); i++) {
            Transaction transaction = transactionHistory.get(i);
            data[i][0] = transaction.getMenuItem().getName();
            data[i][1] = "$" + transaction.getMenuItem().getPrice();
            data[i][2] = transaction.getTransactionDate();
            data[i][3] = "$" + transaction.getTotalCost();
        }

        String[] columnNames = {"Item", "Price", "Date", "Total Cost"};
        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);

        // Display total cost
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);
        JLabel totalCostLabel = new JLabel("Total Cost: $" + totalCost, SwingConstants.RIGHT);
        totalCostLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(totalCostLabel, BorderLayout.SOUTH);

        JOptionPane.showMessageDialog(this, panel, "Transaction History", JOptionPane.INFORMATION_MESSAGE);
    }

    private void topUpCredit() {
        String topUpAmountStr = JOptionPane.showInputDialog(this, "Enter top-up amount:", "Top-Up Credit", JOptionPane.PLAIN_MESSAGE);
        double topUpAmount;

        try {
            topUpAmount = Double.parseDouble(topUpAmountStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid amount.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (topUpAmount > 0) {
            userService.topUpCredit(customer, topUpAmount);
            JOptionPane.showMessageDialog(this, "Credit topped up successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            refreshTotalLabel(); // Update total credit label
        } else {
            JOptionPane.showMessageDialog(this, "Please enter a positive amount.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshTotalLabel() {
        totalLabel.setText("Total Credit: $" + customer.getCredit());
    }

    public static void main(String[] args) {
        UserService userService = new UserService(); // Create an instance of UserService
        Customer customer = new Customer("customer", "password", "John", "Doe", "1111111111", "customer@example.com");
        SwingUtilities.invokeLater(() -> new CustomerView(null, customer, userService).setVisible(true));
    }
}

