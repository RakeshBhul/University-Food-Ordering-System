package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import models.User;
import services.UserService;

public class UpdateUserView extends JFrame {
    private UserService userService;
    private JComboBox<String> roleComboBox;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField contactField;
    private JTextField emailField;
    private JButton updateButton;
    private JButton backButton;
    private JFrame previousWindow;

    public UpdateUserView(JFrame previousWindow, UserService userService) {
        this.previousWindow = previousWindow;
        this.userService = userService;
        setTitle("Update User");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Update User", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel roleLabel = new JLabel("Role:");
        roleComboBox = new JComboBox<>(new String[] { "Customer", "Vendor", "DeliveryRunner" });

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameField = new JTextField(20);
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameField = new JTextField(20);
        JLabel contactLabel = new JLabel("Contact:");
        contactField = new JTextField(20);
        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField(20);

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(roleLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(roleComboBox, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(usernameLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(usernameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        formPanel.add(passwordField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(firstNameLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        formPanel.add(firstNameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(lastNameLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 4;
        formPanel.add(lastNameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(contactLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 5;
        formPanel.add(contactField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(emailLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 6;
        formPanel.add(emailField, gbc);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        updateButton = new JButton("Update");
        backButton = new JButton("Back");
        buttonPanel.add(updateButton);
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);

        updateButton.addActionListener(e -> updateUser());
        backButton.addActionListener(e -> {
            previousWindow.setVisible(true);
            dispose();
        });

        setPreferredSize(new Dimension(600, 400));  // Set initial preferred size
        pack();  // Adjust the frame to fit the preferred size of its components
        setLocationRelativeTo(null);  // Center the frame on the screen
        setResizable(true);  // Allow the frame to be resizable
    }

    private void updateUser() {
        String role = (String) roleComboBox.getSelectedItem();
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String contact = contactField.getText();
        String email = emailField.getText();

        if (!username.isEmpty()) {
            boolean success = userService.updateUser(role, username, password, firstName, lastName, contact, email);
            if (success) {
                JOptionPane.showMessageDialog(this, "User updated successfully!");
                usernameField.setText("");
                passwordField.setText("");
                firstNameField.setText("");
                lastNameField.setText("");
                contactField.setText("");
                emailField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "User not found.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Username field must be filled out.");
        }
    }

    public static void main(String[] args) {
        UserService userService = new UserService();
        SwingUtilities.invokeLater(() -> new UpdateUserView(null, userService).setVisible(true));
    }
}
