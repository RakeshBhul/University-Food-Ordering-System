package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import models.DeliveryRunner;
import models.Order;
import models.Customer;
import models.MenuItem;
import services.OrderService;
import services.UserService;

public class DeliveryRunnerView extends JFrame {
    private DeliveryRunner deliveryRunner;
    private OrderService orderService;
    private JTextArea orderArea;
    private JButton acceptOrderButton;
    private JButton rejectOrderButton;
    private JButton historyButton;
    private JButton backButton;
    private UserService userService;
    private JFrame previousWindow;

    public DeliveryRunnerView(JFrame previousWindow, DeliveryRunner deliveryRunner, UserService userService) {
        this.previousWindow = previousWindow;
        this.deliveryRunner = deliveryRunner;
        this.userService = userService;
        this.orderService = new OrderService(userService); // Initialize OrderService with UserService

        setTitle("Delivery Runner Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Delivery Runner Dashboard", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        topPanel.add(titleLabel, BorderLayout.CENTER);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(0xDC3545)); // Red
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                previousWindow.setVisible(true); // Show the previous window
            }
        });
        topPanel.add(backButton, BorderLayout.WEST);

        add(topPanel, BorderLayout.NORTH);

        orderArea = new JTextArea();
        orderArea.setEditable(false);
        add(new JScrollPane(orderArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        acceptOrderButton = new JButton("Accept Order");
        rejectOrderButton = new JButton("Reject Order");
        historyButton = new JButton("Order History");

        buttonPanel.add(acceptOrderButton);
        buttonPanel.add(rejectOrderButton);
        buttonPanel.add(historyButton);
        add(buttonPanel, BorderLayout.SOUTH);

        acceptOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                acceptOrder();
            }
        });

        rejectOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rejectOrder();
            }
        });

        historyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewOrderHistory();
            }
        });

        setPreferredSize(new Dimension(600, 400)); // Set initial preferred size
        pack(); // Adjust the frame to fit the preferred size of its components
        setLocationRelativeTo(null); // Center the frame on the screen
        setResizable(true); // Allow the frame to be resizable

        loadOrdersFromFile(); // Load orders directly from the text file
    }

    private void loadOrdersFromFile() {
        orderArea.setText(""); // Clear existing orders
        List<Order> pendingOrders = readOrdersFromTextFile();

        for (Order order : pendingOrders) {
            orderArea.append("Order ID: " + order.getId() + "\nCustomer: " + order.getCustomer().getUsername() + "\nMenuItem: " + order.getMenuItem().getName() + "\n\n");
        }
    }

    private List<Order> readOrdersFromTextFile() {
        List<Order> orders = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 8) {
                    int id = Integer.parseInt(parts[0]);
                    Customer customer = userService.getCustomerByUsername(parts[1]);
                    double itemPrice = Double.parseDouble(parts[3]);
                    MenuItem menuItem = new MenuItem(parts[2], itemPrice, "");
                    String date = parts[4];
                    boolean accepted = Boolean.parseBoolean(parts[5]);
                    boolean rejected = Boolean.parseBoolean(parts[6]);
                    DeliveryRunner deliveryRunner = userService.getDeliveryRunnerByUsername(parts[7]);

                    Order order = new Order(customer, menuItem, date);
                    order.setId(id); // Ensure the order ID is set
                    order.setAccepted(accepted);
                    order.setRejected(rejected);
                    order.setDeliveryRunner(deliveryRunner);
                    orders.add(order);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orders;
    }

    private void acceptOrder() {
        try {
            String orderId = JOptionPane.showInputDialog(this, "Enter Order ID to accept:");
            if (orderId != null && !orderId.trim().isEmpty()) {
                boolean success = orderService.acceptOrder(Integer.parseInt(orderId), deliveryRunner);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Order accepted!");
                    loadOrdersFromFile();
                } else {
                    JOptionPane.showMessageDialog(this, "Error accepting order.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Order ID.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error accepting order: " + e.getMessage());
        }
    }

    private void rejectOrder() {
        try {
            String orderId = JOptionPane.showInputDialog(this, "Enter Order ID to reject:");
            if (orderId != null && !orderId.trim().isEmpty()) {
                boolean success = orderService.rejectOrder(Integer.parseInt(orderId), deliveryRunner);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Order rejected.");
                    loadOrdersFromFile();
                                } else {
                    JOptionPane.showMessageDialog(this, "Error rejecting order.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Order ID.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error rejecting order: " + e.getMessage());
        }
    }

    private void viewOrderHistory() {
        try {
            List<Order> orderHistory = orderService.getOrderHistory(deliveryRunner);
            orderArea.setText(""); // Clear existing orders

            for (Order order : orderHistory) {
                orderArea.append("Order ID: " + order.getId() + "\nCustomer: " + order.getCustomer().getUsername() + "\nMenuItem: " + order.getMenuItem().getName() + "\n\n");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error viewing order history: " + e.getMessage());
        }
    }

    private void readOrdersFromFile() {
        orderArea.setText(""); // Clear existing orders
        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 8) {
                    int id = Integer.parseInt(parts[0]);
                    String customerUsername = parts[1];
                    String menuItemName = parts[2];
                    double menuItemPrice = Double.parseDouble(parts[3]);
                    String orderDate = parts[4];
                    boolean accepted = Boolean.parseBoolean(parts[5]);
                    boolean rejected = Boolean.parseBoolean(parts[6]);
                    String deliveryRunnerUsername = parts[7];

                    if (!accepted && !rejected) {
                        orderArea.append("Order ID: " + id + "\nCustomer: " + customerUsername + "\nMenuItem: " + menuItemName + "\n\n");
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading orders: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        DeliveryRunner deliveryRunner = new DeliveryRunner("runner_username", "runner_password", "RunnerFirstName", "RunnerLastName", "RunnerContact", "RunnerEmail");
        UserService userService = new UserService();
        SwingUtilities.invokeLater(() -> new DeliveryRunnerView(null, deliveryRunner, userService).setVisible(true));
    }
}
