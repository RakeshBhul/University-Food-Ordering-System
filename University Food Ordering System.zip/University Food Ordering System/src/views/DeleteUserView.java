package views;

import javax.swing.*;
import java.awt.*;
import models.Administrator;
import services.UserService;

public class DeleteUserView extends JFrame {
    private Administrator administrator;
    private UserService userService;
    private JTextField usernameField;
    private JButton deleteButton;
    private JButton backButton;
    private JFrame previousWindow;

    public DeleteUserView(JFrame previousWindow, UserService userService) {
        this.previousWindow = previousWindow;
        this.userService = userService;

        setTitle("Delete User");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Delete User", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField(20);

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(usernameLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(usernameField, gbc);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        deleteButton = new JButton("Delete");
        backButton = new JButton("Back");
        buttonPanel.add(deleteButton);
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);

        deleteButton.addActionListener(e -> deleteUser());
        backButton.addActionListener(e -> {
            previousWindow.setVisible(true);
            dispose();
        });

        setPreferredSize(new Dimension(600, 400));  // Set initial preferred size
        pack();  // Adjust the frame to fit the preferred size of its components
        setLocationRelativeTo(null);  // Center the frame on the screen
        setResizable(true);  // Allow the frame to be resizable
    }

    private void deleteUser() {
        String username = usernameField.getText();

        if (!username.isEmpty()) {
            boolean success = userService.deleteUser(username);

            if (success) {
                JOptionPane.showMessageDialog(this, "User deleted successfully!");
                usernameField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "User not found.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Username field must be filled out.");
        }
    }

    public static void main(String[] args) {
        UserService userService = new UserService();
        SwingUtilities.invokeLater(() -> new DeleteUserView(null, userService).setVisible(true));
    }
}
