 package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import services.UserService;
import models.*;

public class RegistrationView extends JFrame {
    private UserService userService;
    private JComboBox<String> roleComboBox;
    private JTextField usernameField;
    private JLabel usernameWarningLabel;
    private JPasswordField passwordField;
    private JLabel passwordWarningLabel;
    private JTextField firstNameField;
    private JLabel firstNameWarningLabel;
    private JTextField lastNameField;
    private JLabel lastNameWarningLabel;
    private JTextField contactField;
    private JLabel contactWarningLabel;
    private JTextField emailField;
    private JLabel emailWarningLabel;
    private JButton registerButton;
    private JButton backButton;
    private JFrame previousWindow;

    public RegistrationView(JFrame previousWindow, UserService userService) {
        this.previousWindow = previousWindow;
        this.userService = userService;
        setTitle("User Registration");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Register User", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel roleLabel = new JLabel("Role:");
        roleComboBox = new JComboBox<>(new String[]{"Administrator", "Customer", "Vendor", "DeliveryRunner"});

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField(20);
        usernameWarningLabel = new JLabel("Invalid username");
        usernameWarningLabel.setForeground(Color.RED);
        usernameWarningLabel.setVisible(false);

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);
        passwordWarningLabel = new JLabel("Invalid password");
        passwordWarningLabel.setForeground(Color.RED);
        passwordWarningLabel.setVisible(false);

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameField = new JTextField(20);
        firstNameWarningLabel = new JLabel("Invalid first name");
        firstNameWarningLabel.setForeground(Color.RED);
        firstNameWarningLabel.setVisible(false);

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameField = new JTextField(20);
        lastNameWarningLabel = new JLabel("Invalid last name");
        lastNameWarningLabel.setForeground(Color.RED);
        lastNameWarningLabel.setVisible(false);

        JLabel contactLabel = new JLabel("Contact:");
        contactField = new JTextField(20);
        contactWarningLabel = new JLabel("Invalid contact number");
        contactWarningLabel.setForeground(Color.RED);
        contactWarningLabel.setVisible(false);

        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField(20);
        emailWarningLabel = new JLabel("Invalid email");
        emailWarningLabel.setForeground(Color.RED);
        emailWarningLabel.setVisible(false);

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(roleLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(roleComboBox, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(usernameLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(usernameField, gbc);
        gbc.gridx = 2;
        formPanel.add(usernameWarningLabel, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(passwordField, gbc);
        gbc.gridx = 2;
        formPanel.add(passwordWarningLabel, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(firstNameLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(firstNameField, gbc);
        gbc.gridx = 2;
        formPanel.add(firstNameWarningLabel, gbc);
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(lastNameLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(lastNameField, gbc);
        gbc.gridx = 2;
        formPanel.add(lastNameWarningLabel, gbc);
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(contactLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(contactField, gbc);
        gbc.gridx = 2;
        formPanel.add(contactWarningLabel, gbc);
        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(emailLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(emailField, gbc);
        gbc.gridx = 2;
        formPanel.add(emailWarningLabel, gbc);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        registerButton = new JButton("Register");
        backButton = new JButton("Back");
        buttonPanel.add(registerButton);
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);

        registerButton.addActionListener(e -> registerUser());
        backButton.addActionListener(e -> {
            previousWindow.setVisible(true);
            dispose();
        });

        // Add key listeners for real-time validation
        addValidationListeners();

        setPreferredSize(new Dimension(600, 400));  // Set initial preferred size
        pack();  // Adjust the frame to fit the preferred size of its components
        setLocationRelativeTo(null);  // Center the frame on the screen
        setResizable(true);  // Allow the frame to be resizable
    }

    private void addValidationListeners() {
        usernameField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (isValidUsername(usernameField.getText())) {
                    usernameWarningLabel.setVisible(false);
                } else {
                    usernameWarningLabel.setVisible(true);
                }
            }
        });

        passwordField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (isValidPassword(new String(passwordField.getPassword()))) {
                    passwordWarningLabel.setVisible(false);
                } else {
                    passwordWarningLabel.setVisible(true);
                }
            }
        });

        firstNameField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (isValidName(firstNameField.getText())) {
                    firstNameWarningLabel.setVisible(false);
                } else {
                    firstNameWarningLabel.setVisible(true);
                }
            }
        });

        lastNameField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (isValidName(lastNameField.getText())) {
                    lastNameWarningLabel.setVisible(false);
                } else {
                    lastNameWarningLabel.setVisible(true);
                }
            }
        });

        contactField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (isValidContact(contactField.getText())) {
                    contactWarningLabel.setVisible(false);
                } else {
                    contactWarningLabel.setVisible(true);
                }
            }
        });

        emailField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (isValidEmail(emailField.getText())) {
                    emailWarningLabel.setVisible(false);
                } else {
                    emailWarningLabel.setVisible(true);
                }
            }
        });
    }

    private boolean isValidInput(String username, String password, String firstName, String lastName, String contact, String email) {
        return isValidUsername(username) && isValidPassword(password) && isValidName(firstName) && isValidName(lastName) && isValidContact(contact) && isValidEmail(email);
    }

    private boolean isValidUsername(String username) {
        return username != null && username.matches("[A-Za-z0-9_]+");
    }

    private boolean isValidPassword(String password) {
        return password != null && password.length() >= 6;
    }

    private boolean isValidName(String name) {
        return name != null && name.matches("[A-Za-z]+");
    }

    private boolean isValidContact(String contact) {
        return contact != null && contact.matches("\\d{10}");
    }

    private boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    private void registerUser() {
        String role = (String) roleComboBox.getSelectedItem();
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String contact = contactField.getText();
        String email = emailField.getText();

        if (isValidInput(username, password, firstName, lastName, contact, email)) {
            User user = null;
            switch (role) {
                case "Administrator":
                    user = new Administrator(username, password, firstName, lastName, contact, email);
                    break;
                case "Customer":
                    user = new Customer(username, password, firstName, lastName, contact, email);
                    break;
                case "Vendor":
                    user = new Vendor(username, password, firstName, lastName, contact, email);
                    break;
                case "DeliveryRunner":
                    user = new DeliveryRunner(username, password, firstName, lastName, contact, email);
                    break;
            }
            if (user != null) {
                userService.registerUser(user);
                JOptionPane.showMessageDialog(this, "User registered successfully!");
                resetForm();
            } else {
                JOptionPane.showMessageDialog(this, "Error creating user.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid input data.");
        }
    }

    private void resetForm() {
        usernameField.setText("");
        passwordField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        contactField.setText("");
        emailField.setText("");
    }

    public static void main(String[] args) {
        UserService userService = new UserService();
        SwingUtilities.invokeLater(() -> new RegistrationView(null, userService).setVisible(true));
    }
}
