package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.filechooser.FileNameExtensionFilter;
import services.UserService;
import models.MenuItem;
import java.awt.image.BufferedImage;
import java.util.List;

public class VendorView extends JFrame {
    private UserService userService;
    private JTextField itemNameField;
    private JTextField itemPriceField;
    private JTextField itemImagePathField;
    private JButton addItemButton;
    private JButton removeItemButton;
    private JButton browseImageButton;
    private JButton backButton;
    private JPanel menuPanel;
    private JFrame previousWindow;

    public VendorView(JFrame previousWindow, UserService userService) {
        this.previousWindow = previousWindow;
        this.userService = userService;
        setTitle("Vendor Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Vendor Dashboard", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(0x007FFF)); // Light Blue
        topPanel.add(titleLabel, BorderLayout.CENTER);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(0xDC3545)); // Red
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                previousWindow.setVisible(true); // Show the previous window
            }
        });
        backButton.setPreferredSize(new Dimension(100, 40));
        topPanel.add(backButton, BorderLayout.WEST);

        add(topPanel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel itemNameLabel = new JLabel("Item Name:");
        itemNameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(itemNameLabel, gbc);

        itemNameField = new JTextField();
        itemNameField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 0;
        inputPanel.add(itemNameField, gbc);

        JLabel itemPriceLabel = new JLabel("Item Price:");
        itemPriceLabel.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(itemPriceLabel, gbc);

        itemPriceField = new JTextField();
        itemPriceField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 1;
        inputPanel.add(itemPriceField, gbc);

        JLabel itemImagePathLabel = new JLabel("Image Path:");
        itemImagePathLabel.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        inputPanel.add(itemImagePathLabel, gbc);

        itemImagePathField = new JTextField();
        itemImagePathField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 2;
        inputPanel.add(itemImagePathField, gbc);

        browseImageButton = new JButton("Browse");
        browseImageButton.setFont(new Font("Arial", Font.BOLD, 14));
        browseImageButton.setForeground(Color.WHITE);
        browseImageButton.setBackground(new Color(0x17a2b8)); // Cyan
        browseImageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser("src/images");
                FileNameExtensionFilter filter = new FileNameExtensionFilter("Image Files", "jpg", "png", "jpeg");
                fileChooser.setFileFilter(filter);
                int result = fileChooser.showOpenDialog(VendorView.this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    itemImagePathField.setText(selectedFile.getAbsolutePath());
                }
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 3;
        inputPanel.add(browseImageButton, gbc);

        addItemButton = new JButton("Add Item");
        addItemButton.setFont(new Font("Arial", Font.BOLD, 14));
        addItemButton.setForeground(Color.WHITE);
        addItemButton.setBackground(new Color(0x28A745)); // Green
        addItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addItem();
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 4;
        inputPanel.add(addItemButton, gbc);

        removeItemButton = new JButton("Remove Item");
        removeItemButton.setFont(new Font("Arial", Font.BOLD, 14));
        removeItemButton.setForeground(Color.WHITE);
        removeItemButton.setBackground(new Color(0xDC3545)); // Red
        removeItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeItem();
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 4;
        inputPanel.add(removeItemButton, gbc);

        add(inputPanel, BorderLayout.SOUTH);

        menuPanel = new JPanel(new GridBagLayout());
        menuPanel.setBackground(new Color(0xFFFFFF)); // White background
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(new JScrollPane(menuPanel), BorderLayout.CENTER);

        setPreferredSize(new Dimension(1000, 800));
        pack();
        setLocationRelativeTo(null);
        setResizable(true);
        refreshMenu();
    }

    private void addItem() {
        String itemName = itemNameField.getText();
        String itemPriceStr = itemPriceField.getText();
        String itemImagePath = itemImagePathField.getText();
        double itemPrice;

        try {
            itemPrice = Double.parseDouble(itemPriceStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!itemName.isEmpty() && itemPrice > 0 && !itemImagePath.isEmpty()) {
            userService.addMenuItem(new MenuItem(itemName, itemPrice, itemImagePath));
            JOptionPane.showMessageDialog(this, "Item added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            itemNameField.setText("");
            itemPriceField.setText("");
            itemImagePathField.setText("");
            refreshMenu();
        } else {
            JOptionPane.showMessageDialog(this, "Please enter item name, valid price, and image path.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

       private void removeItem() {
        String itemName = itemNameField.getText();
        if (userService.removeMenuItem(itemName)) {
            JOptionPane.showMessageDialog(this, "Item removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            itemNameField.setText("");
            itemPriceField.setText("");
            refreshMenu();
        } else {
            JOptionPane.showMessageDialog(this, "Item not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshMenu() {
        menuPanel.removeAll();
        List<MenuItem> menuItems = userService.getAllMenuItems();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 0.5;
        gbc.weighty = 1;

        int col = 0;

        for (MenuItem item : menuItems) {
            JPanel itemPanel = new JPanel(new BorderLayout());
            itemPanel.setBackground(new Color(0xFFFFFF)); // White background
            itemPanel.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0), 1));
            itemPanel.setPreferredSize(new Dimension(300, 400)); // Set preferred size for the item panel

            JLabel itemLabel = new JLabel(item.getName() + " - $" + item.getPrice(), SwingConstants.CENTER);
            itemLabel.setFont(new Font("Arial", Font.BOLD, 16));
            itemPanel.add(itemLabel, BorderLayout.NORTH);

            ImageIcon imageIcon = loadImageIcon(item.getImagePath(), 200, 200); // Resize image to fit the space
            JLabel imageLabel = new JLabel(imageIcon);
            imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
            itemPanel.add(imageLabel, BorderLayout.CENTER);

            gbc.gridx = col % 2;
            gbc.gridy = col / 2;
            menuPanel.add(itemPanel, gbc);
            col++;
        }

        menuPanel.revalidate();
        menuPanel.repaint();
    }

    private ImageIcon loadImageIcon(String path, int width, int height) {
        try {
            BufferedImage img = ImageIO.read(new File(path));
            Image scaledImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            return new ImageIcon(scaledImg);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        UserService userService = new UserService(); // Create an instance of UserService
        SwingUtilities.invokeLater(() -> new VendorView(null, userService).setVisible(true));
    }
}
