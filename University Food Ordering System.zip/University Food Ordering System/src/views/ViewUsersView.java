package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import models.Administrator;
import models.User;
import services.UserService;

public class ViewUsersView extends JFrame {
    private Administrator administrator;
    private UserService userService;
    private JTextArea userArea;
    private JButton backButton;
    private JFrame previousWindow;

    public ViewUsersView(JFrame previousWindow, Administrator administrator) {
        this.previousWindow = previousWindow;
        this.administrator = administrator;
        this.userService = new UserService();

        setTitle("View Users");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("View Users", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, BorderLayout.NORTH);

        userArea = new JTextArea();
        userArea.setEditable(false);
        add(new JScrollPane(userArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        backButton = new JButton("Back");
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                previousWindow.setVisible(true);
                dispose();
            }
        });

        setPreferredSize(new Dimension(600, 400));  // Set initial preferred size
        pack();  // Adjust the frame to fit the preferred size of its components
        setLocationRelativeTo(null);  // Center the frame on the screen
        setResizable(true);  // Allow the frame to be resizable

        loadUsers();
    }

    private void loadUsers() {
        userArea.setText("");  // Clear existing users
        try {
            List<User> users = userService.getAllUsers();
            for (User user : users) {
                userArea.append(user.getUsername() + ": " + user.getFName() + " " + user.getLName() + "\n");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading users: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        Administrator admin = new Administrator("admin_username", "admin_password", "AdminFirstName", "AdminLastName", "AdminContact", "AdminEmail");
        SwingUtilities.invokeLater(() -> new ViewUsersView(null, admin).setVisible(true));
    }
}
