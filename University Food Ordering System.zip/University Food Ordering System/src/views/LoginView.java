package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import models.Customer;
import models.DeliveryRunner;
import services.UserService;
import models.User;
import university.food.ordering.system.Main;

public class LoginView extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox showPasswordCheckBox;
    private JCheckBox rememberMeCheckBox;
    private JButton loginButton;
    private JButton homeButton;
    private JLabel forgotPasswordLabel;
    private UserService userService;
    private String role;

    // Constructor accepting UserService and role as parameters
    public LoginView(UserService userService, String role) {
        this.userService = userService;
        this.role = role;

        setTitle(role + " Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Load the background image
        JLabel backgroundLabel = new JLabel(new ImageIcon(getClass().getResource("/images/Background3.jpg")));
        backgroundLabel.setLayout(new GridBagLayout());
        add(backgroundLabel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15); // Adjusted spacing
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weighty = 0.3;  // Add some vertical space at the top

        JLabel titleLabel = new JLabel("Welcome to Tech University Food Ordering System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Increased font size
        titleLabel.setForeground(new Color(0x007FFF)); // Set font color to light blue
        backgroundLabel.add(titleLabel, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        gbc.weighty = 0;  // Reset weight for other components

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 16)); // Increased font size
        usernameLabel.setForeground(Color.DARK_GRAY); // Set font color to dark gray
        backgroundLabel.add(usernameLabel, gbc);

        gbc.gridx++;
        usernameField = new JTextField(15);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 16)); // Increased font size
        backgroundLabel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 16)); // Increased font size
        passwordLabel.setForeground(Color.DARK_GRAY); // Set font color to dark gray
        backgroundLabel.add(passwordLabel, gbc);

        gbc.gridx++;
        passwordField = new JPasswordField(15);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 16)); // Increased font size
        backgroundLabel.add(passwordField, gbc);

        showPasswordCheckBox = new JCheckBox("Show Password");
        showPasswordCheckBox.setFont(new Font("Arial", Font.PLAIN, 14)); // Adjusted font size
        showPasswordCheckBox.addActionListener(e -> {
            if (showPasswordCheckBox.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            }
        });

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        backgroundLabel.add(showPasswordCheckBox, gbc);

        rememberMeCheckBox = new JCheckBox("Remember Me");
        rememberMeCheckBox.setFont(new Font("Arial", Font.PLAIN, 14)); // Adjusted font size

        gbc.gridy++;
        backgroundLabel.add(rememberMeCheckBox, gbc);

        forgotPasswordLabel = new JLabel("Forgot Password?");
        forgotPasswordLabel.setFont(new Font("Arial", Font.PLAIN, 14)); // Adjusted font size
        forgotPasswordLabel.setForeground(Color.BLUE.darker()); // Set font color to dark blue
        forgotPasswordLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        forgotPasswordLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                JOptionPane.showMessageDialog(LoginView.this, "Password recovery link sent!");
            }
        });

        gbc.gridy++;
        backgroundLabel.add(forgotPasswordLabel, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setOpaque(false); // Make the panel transparent

        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 16)); // Increased font size
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(new Color(0x007FFF)); // Set background color to light blue
        buttonPanel.add(loginButton);

        homeButton = new JButton("Home");
        homeButton.setFont(new Font("Arial", Font.BOLD, 16)); // Increased font size
        homeButton.setForeground(Color.WHITE);
        homeButton.setBackground(new Color(0x17a2b8)); // Cyan
        buttonPanel.add(homeButton);

        gbc.gridy++;
        backgroundLabel.add(buttonPanel, gbc);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (isValidInput(username, password)) {
                    String normalizedRole = role.replaceAll("\\s", "").toLowerCase();
                    User user = userService.authenticate(username, password, normalizedRole);
                    if (user != null) {
                        openView(normalizedRole, user);
                    } else {
                        JOptionPane.showMessageDialog(LoginView.this, "Invalid credentials", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(LoginView.this, "Invalid input data", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Return to the main home page
                new Main().main(null);
                dispose(); // Close the current window
            }
        });

        setPreferredSize(new Dimension(800, 600)); // Set the preferred size of the login window
        pack(); // Adjust the frame to fit the preferred size of its components
        setLocationRelativeTo(null); // Center the frame on the screen
    }

    private boolean isValidInput(String username, String password) {
        return username != null && username.matches("[A-Za-z0-9_]+")
                && password != null && password.length() >= 6;
    }

    private void openView(String role, User user) {
        JFrame view = null;
        switch (role) {
            case "administrator":
                view = new AdministratorView(this, userService);
                break;
            case "customer":
                view = new CustomerView(this, (Customer) user, userService);
                break;
            case "deliveryrunner":
                view = new DeliveryRunnerView(this, (DeliveryRunner) user, userService);
                break;
            case "vendor":
                view = new VendorView(this, userService);
                break;
        }
        if (view != null) {
            view.setVisible(true);
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        UserService userService = new UserService(); // Create an instance of UserService
        SwingUtilities.invokeLater(() -> new LoginView(userService, "Delivery Runner").setVisible(true));
    }
}
