package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import services.OrderService;
import services.NotificationSystem;
import services.UserService;
import models.Customer;
import java.util.List;

public class AdministratorView extends JFrame {
    private JButton addButton;
    private JButton deleteButton;
    private JButton updateButton;
    private JButton backButton;
    private JButton generateReceiptButton;
    private UserService userService;
    private OrderService orderService;
    private NotificationSystem notificationSystem;
    private JFrame previousWindow;

    public AdministratorView(JFrame previousWindow, UserService userService) {
        this.previousWindow = previousWindow;
        this.userService = userService;
        this.orderService = new OrderService(userService);
        this.notificationSystem = new NotificationSystem(userService);

        setTitle("Administrator Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Administrator Dashboard", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(0x007FFF)); // Light Blue
        topPanel.add(titleLabel, BorderLayout.CENTER);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(0xDC3545)); // Red
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                previousWindow.setVisible(true); // Show the previous window
            }
        });
        topPanel.add(backButton, BorderLayout.WEST);

        add(topPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        addButton = new JButton("Add User");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setForeground(Color.WHITE);
        addButton.setBackground(new Color(0x28A745)); // Green

        deleteButton = new JButton("Delete User");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setBackground(new Color(0xDC3545)); // Red

        updateButton = new JButton("Update User");
        updateButton.setFont(new Font("Arial", Font.BOLD, 14));
        updateButton.setForeground(Color.WHITE);
        updateButton.setBackground(new Color(0xFFC107)); // Yellow

        generateReceiptButton = new JButton("Generate Receipt");
        generateReceiptButton.setFont(new Font("Arial", Font.BOLD, 14));
        generateReceiptButton.setForeground(Color.WHITE);
        generateReceiptButton.setBackground(new Color(0x007FFF)); // Light Blue

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(generateReceiptButton);

        add(buttonPanel, BorderLayout.CENTER);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> new RegistrationView(AdministratorView.this, userService).setVisible(true));
                setVisible(false);
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> new DeleteUserView(AdministratorView.this, userService).setVisible(true));
                setVisible(false);
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> new UpdateUserView(AdministratorView.this, userService).setVisible(true));
                setVisible(false);
            }
        });

        generateReceiptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCustomerSelectionDialog();
            }
        });

        setPreferredSize(new Dimension(800, 600));
        pack();
        setLocationRelativeTo(null);
        setResizable(true);
    }

    private void showCustomerSelectionDialog() {
        // Create a new dialog for selecting the customer
        JDialog dialog = new JDialog(this, "Select Customer", true);
        dialog.setLayout(new BorderLayout());

        List<Customer> customers = userService.getUsersByRole(Customer.class);
        JComboBox<String> customerComboBox = new JComboBox<>();
        customerComboBox.addItem("Select Customer");
        for (Customer customer : customers) {
            customerComboBox.addItem(customer.getUsername());
        }

        dialog.add(customerComboBox, BorderLayout.CENTER);

        JButton selectButton = new JButton("Generate Receipt");
        selectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedUsername = (String) customerComboBox.getSelectedItem();
                if (!"Select Customer".equals(selectedUsername)) {
                    Customer customer = userService.getCustomerByUsername(selectedUsername);
                    if (customer != null) {
                        orderService.generateReceiptFile(customer);
                        JOptionPane.showMessageDialog(AdministratorView.this, "Receipt generated and saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        dialog.dispose();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "No customer selected!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(dialog, "No customer selected!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        dialog.add(selectButton, BorderLayout.SOUTH);

        dialog.setSize(300, 150);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    public static void main(String[] args) {
        UserService userService = new UserService(); // Create an instance of UserService
        SwingUtilities.invokeLater(() -> new AdministratorView(null, userService).setVisible(true));
    }
}
