package models;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class Order implements Serializable {
    private Customer customer;
    private List<String> items;
    private double totalAmount;
    private MenuItem menuItem;
    private LocalDate orderDate;
    private boolean accepted;
    private boolean rejected;
    private DeliveryRunner deliveryRunner;
    private int id;
    private static int nextId = 1; // Counter for generating unique IDs

    public Order(Customer customer, MenuItem menuItem) {
        this.customer = customer;
        this.menuItem = menuItem;
        this.orderDate = LocalDate.now(); // Set the order date to the current date
        this.id = nextId++; // Assign unique ID and increment the counter
        this.accepted = false;
        this.rejected = false;
    }

    public Order(Customer customer, List<String> items, double totalAmount) {
        this.customer = customer;
        this.items = items;
        this.totalAmount = totalAmount;
        this.orderDate = LocalDate.now(); // Set the order date to the current date
        this.id = nextId++; // Assign unique ID and increment the counter
        this.accepted = true;
        this.rejected = false;
    }

    public Order(Customer customer, MenuItem menuItem, String orderDateString) {
        this.customer = customer;
        this.menuItem = menuItem;
        this.orderDate = LocalDate.parse(orderDateString, DateTimeFormatter.ISO_DATE); // Parse the string to LocalDate
        this.id = nextId++; // Assign unique ID and increment the counter
        this.accepted = false;
        this.rejected = false;
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<String> getItems() {
        return items;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public MenuItem getMenuItem() {
        return menuItem;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public boolean isAccepted() {
        return accepted;
    }

    public int getId() {
        return id;
    }

    public void setAccepted(boolean accepted) {
        this.accepted = accepted;
    }

    public void setRejected(boolean rejected) {
        this.rejected = rejected;
    }

    public boolean isRejected() {
        return rejected;
    }

    public void setDeliveryRunner(DeliveryRunner deliveryRunner) {
        this.deliveryRunner = deliveryRunner;
    }

    public DeliveryRunner getDeliveryRunner() {
        return deliveryRunner;
    }

    public void setId(int id) {
        this.id = id;
    }
}
