package models;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Transaction implements Serializable {
    private Customer customer;
    private MenuItem menuItem;
    private LocalDate date;
    private double totalCost;

    // Constructor
    public Transaction(Customer customer, MenuItem menuItem, LocalDate date, double totalCost) {
        this.customer = customer;
        this.menuItem = menuItem;
        this.date = date;
        this.totalCost = totalCost;
    }

    // Constructor with string date
    public Transaction(Customer customer, MenuItem menuItem, String transactionDateString, double totalCost) {
        this.customer = customer;
        this.menuItem = menuItem;
        this.date = LocalDate.parse(transactionDateString, DateTimeFormatter.ISO_DATE); // Parse the string to LocalDate
        this.totalCost = totalCost;
    }

    public Customer getCustomer() {
        return customer;
    }

    public MenuItem getMenuItem() {
        return menuItem;
    }

    public LocalDate getDate() {
        return date;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public String getTransactionDateString() {
        return date.format(DateTimeFormatter.ISO_DATE);
    }

    public Object getTransactionDate() {
        return date;
    }
}
