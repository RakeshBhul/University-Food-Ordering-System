package models;

public class DeliveryRunner extends User {
    public DeliveryRunner(String username, String password, String firstName, String lastName, String contact, String email){
        super(username, password, firstName, lastName, contact, email);
    }

    // Additional methods specific to DeliveryRunner can be added here

    // Example of a method to accept an order
    public void acceptOrder(Order order) {
        // Implementation for accepting the order
    }

    // Example of a method to view order history
    public void viewOrderHistory() {
        // Implementation for viewing order history
    }
}
