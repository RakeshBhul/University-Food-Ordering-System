package models;

import java.io.Serializable;

public class Vendor extends User implements Serializable {
    private static final long serialVersionUID = 1L;

    private String fName;
    private String lName;
    private String contact;
    private String email;

    public Vendor(String username, String password, String fName, String lName, String contact, String email) {
        super(username, password, fName, lName, contact, email);
        this.fName = fName;
        this.lName = lName;
        this.contact = contact;
        this.email = email;
    }

    // Getters and setters for the new fields
    public String getFName() {
        return fName;
    }

    public void setFName(String fName) {
        this.fName = fName;
    }

    public String getLName() {
        return lName;
    }

    public void setLName(String lName) {
        this.lName = lName;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
