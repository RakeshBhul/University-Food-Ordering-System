package models;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;

public class Customer extends User implements Serializable {
    private static final long serialVersionUID = 2969900151736678064L;
    private double credit; // Field to store the credit balance

    public Customer(String username, String password, String fName, String lName, String contact, String email) {
        super(username, password, fName, lName, contact, email);
        this.credit = 0.0; // Initialize credit to zero or any default value
    }

    public String getName() {
        return getFName() + " " + getLName();
    }

    public void addCredit(double amount) {
        setCredit(getCredit() + amount);
    }

    public double getCredit() {
        return credit;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }

    @Override
    public String getFName() {
        return super.getFName();
    }

    @Override
    public String getLName() {
        return super.getLName();
    }

    public void loadCreditFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(this.getUsername() + "_credit.txt"))) {
            this.credit = Double.parseDouble(reader.readLine());
        } catch (IOException e) {
            e.printStackTrace();
            this.credit = 0.0; // Default to 0 if file reading fails
        }
    }
}
