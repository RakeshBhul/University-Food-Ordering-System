package services;

import models.Customer;

public class PaymentService {
    private UserService userService;

    public PaymentService(UserService userService) {
        this.userService = userService;
    }

    public void topUpCredit(Customer customer, double amount) {
        if (customer != null) {
            customer.setCredit(customer.getCredit() + amount);
            userService.saveUsersToFile(); // Save updated user information
        }
    }

    public boolean deductCredit(Customer customer, double amount) {
        if (customer != null && customer.getCredit() >= amount) {
            customer.setCredit(customer.getCredit() - amount);
            userService.saveUsersToFile(); // Save updated user information
            return true;
        }
        return false; // Insufficient funds
    }
}
