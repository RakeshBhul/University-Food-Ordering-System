package services;

import models.Order;
import models.MenuItem;
import models.Customer;
import models.Transaction;
import models.DeliveryRunner;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class OrderService {

    private List<Order> orders;
    private UserService userService;

    public OrderService(UserService userService) {
        this.userService = userService;
        this.orders = loadOrdersFromTextFile();
    }

    public void placeOrder(Order order) {
        orders.add(order);
        saveOrdersToTextFile(); // Save to text file
    }

    public boolean placeOrder(Customer customer, MenuItem menuItem) {
        if (customer.getCredit() >= menuItem.getPrice()) {
            Order order = new Order(customer, menuItem);
            orders.add(order);
            saveOrdersToTextFile(); // Save to text file
            return true;
        }
        return false;
    }

    public boolean cancelOrder(Customer customer, MenuItem menuItem) {
        for (Order order : orders) {
            if (order.getCustomer().equals(customer) && order.getMenuItem().equals(menuItem)) {
                orders.remove(order);
                saveOrdersToTextFile(); // Save to text file
                return true;
            }
        }
        return false;
    }

    public void saveOrdersToTextFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("orders.txt"))) {
            for (Order order : orders) {
                writer.write(order.getId() + ","
                        + order.getCustomer().getUsername() + ","
                        + order.getMenuItem().getName() + ","
                        + order.getMenuItem().getPrice() + ","
                        + order.getOrderDate().toString() + ","
                        + order.isAccepted() + ","
                        + order.isRejected() + ","
                        + (order.getDeliveryRunner() != null ? order.getDeliveryRunner().getUsername() : ""));
                writer.newLine();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Order> loadOrdersFromTextFile() {
        List<Order> orders = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 8) {
                    int id = Integer.parseInt(parts[0]);
                    Customer customer = userService.getCustomerByUsername(parts[1]);
                    double itemPrice = Double.parseDouble(parts[3]);
                    MenuItem menuItem = new MenuItem(parts[2], itemPrice, "");
                    String date = parts[4];
                    boolean accepted = Boolean.parseBoolean(parts[5]);
                    boolean rejected = Boolean.parseBoolean(parts[6]);
                    DeliveryRunner deliveryRunner = userService.getDeliveryRunnerByUsername(parts[7]);

                    Order order = new Order(customer, menuItem, date);
                    order.setId(id); // Ensure the order ID is set
                    order.setAccepted(accepted);
                    order.setRejected(rejected);
                    order.setDeliveryRunner(deliveryRunner);
                    orders.add(order);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orders;
    }

    public String generateReceipt(Order order) {
        double totalCost = order.getMenuItem().getPrice();
        return "Receipt\n"
                + "Customer: " + order.getCustomer().getUsername() + "\n"
                + "Item: " + order.getMenuItem().getName() + "\n"
                + "Price: $" + order.getMenuItem().getPrice() + "\n"
                + "Total Cost: $" + totalCost + "\n"
                + "Thank you for your purchase!";
    }

    public void generateReceiptFile(Customer customer) {
        List<Order> customerOrders = getOrdersByCustomer(customer);
        double totalCost = calculateTotalCostByCustomer(customer);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(customer.getUsername() + "_receipt.txt"))) {
            writer.write("Tech University Food Ordering System\n");
            writer.write("=====================================\n");
            writer.write("Customer: " + customer.getUsername() + "\n");
            writer.write("-------------------------------------\n");
            writer.write(String.format("%-20s %10s\n", "Item", "Price"));
            writer.write("-------------------------------------\n");
            for (Order order : customerOrders) {
                writer.write(String.format("%-20s %10.2f\n", order.getMenuItem().getName(), order.getMenuItem().getPrice()));
            }
            writer.write("-------------------------------------\n");
            writer.write(String.format("%-20s %10.2f\n", "Total", totalCost));
            writer.write("=====================================\n");
            writer.write("Thank you for your purchase!\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Order> getAllOrders() {
        return orders;
    }

    public List<Transaction> getTransactionHistoryByCustomer(Customer customer) {
        List<Transaction> customerTransactions = new ArrayList<>();
        for (Order order : orders) {
            if (order.getCustomer().equals(customer)) {
                customerTransactions.add(new Transaction(order.getCustomer(), order.getMenuItem(), order.getOrderDate(), order.getMenuItem().getPrice()));
            }
        }
        return customerTransactions;
    }

    public List<Order> getOrdersByCustomer(Customer customer) {
        List<Order> customerOrders = new ArrayList<>();
        for (Order order : orders) {
            if (order.getCustomer().equals(customer)) {
                customerOrders.add(order);
            }
        }
        return customerOrders;
    }

    // New method to calculate total cost
    public double calculateTotalCostByCustomer(Customer customer) {
        double totalCost = 0.0;
        for (Order order : orders) {
            if (order.getCustomer().equals(customer)) {
                totalCost += order.getMenuItem().getPrice();
            }
        }
        return totalCost;
    }

    public List<Transaction> getAllTransactions() {
        List<Transaction> allTransactions = new ArrayList<>();
        for (Order order : orders) {
            allTransactions.add(new Transaction(order.getCustomer(), order.getMenuItem(), order.getOrderDate(), order.getMenuItem().getPrice()));
        }
        return allTransactions;
    }

    // Methods for DeliveryRunner functionality
    public List<Order> getPendingOrders() {
        return orders.stream().filter(order -> !order.isAccepted() && !order.isRejected()).collect(Collectors.toList());
    }

    public boolean acceptOrder(int orderId, DeliveryRunner deliveryRunner) {
        for (Order order : orders) {
            if (order.getId() == orderId && !order.isAccepted() && !order.isRejected()) {
                order.setAccepted(true);
                order.setDeliveryRunner(deliveryRunner);
                saveOrdersToTextFile(); // Save to text file
                return true;
            }
        }
        return false;
    }

    public boolean rejectOrder(int orderId, DeliveryRunner deliveryRunner) {
        for (Order order : orders) {
            if (order.getId() == orderId && !order.isAccepted() && !order.isRejected()) {
                order.setRejected(true);
                order.setDeliveryRunner(deliveryRunner);
                saveOrdersToTextFile(); // Save to text file
                return true;
            }
        }
        return false;
    }

    public List<Order> getOrderHistory(DeliveryRunner deliveryRunner) {
        return orders.stream().filter(order -> order.getDeliveryRunner() != null && order.getDeliveryRunner().equals(deliveryRunner)).collect(Collectors.toList());
    }
}
