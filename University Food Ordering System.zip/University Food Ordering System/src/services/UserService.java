package services;

import models.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class UserService {
    private List<User> users;
    private List<MenuItem> menuItems;
    private static final String MENU_ITEMS_FILE = "menuItems.txt";
    private static final String USERS_FILE = "users.txt";

    public UserService() {
        // Initialize your users list here, possibly loading from a file
        users = loadUsersFromFile();

        // Ensure the admin user exists
        ensureAdminUser();

        // Load menu items from file
        menuItems = loadMenuItemsFromFile();
    }

    private void ensureAdminUser() {
        // Remove any other admin users to enforce fixed credentials
        users.removeIf(user -> user instanceof Administrator && !user.getUsername().equals("rakesh"));

        boolean adminExists = users.stream()
                .anyMatch(user -> user instanceof Administrator && user.getUsername().equals("rakesh"));

        if (!adminExists) {
            // Create the admin user with username "rakesh" and password "password"
            Administrator admin = new Administrator("rakesh", "password", "Admin", "User", "0000000000", "admin@example.com");
            users.add(admin);
            saveUsersToFile();
        }
    }

    public User authenticate(String username, String password, String role) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                String userRole = user.getClass().getSimpleName().toLowerCase();
                if (userRole.equals(role.toLowerCase())) {
                    return user;
                }
            }
        }
        return null; // Return null if no matching user is found
    }

    public <T extends User> List<T> getUsersByRole(Class<T> roleClass) {
        return users.stream()
                .filter(roleClass::isInstance)
                .map(roleClass::cast)
                .collect(Collectors.toList());
    }

    public void registerUser(User user) {
        if (isValidUser(user)) {
            users.add(user);
            saveUsersToFile();
        } else {
            System.out.println("Invalid user data.");
        }
    }

    private boolean isValidUser(User user) {
        return user.getUsername() != null && user.getUsername().matches("[A-Za-z0-9_]+")
                && user.getPassword() != null && user.getPassword().length() >= 6
                && user.getFName() != null && user.getFName().matches("[A-Za-z]+")
                && user.getLName() != null && user.getLName().matches("[A-Za-z]+")
                && user.getContact() != null && user.getContact().matches("\\d{10}")
                && user.getEmail() != null && user.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    public boolean deleteUser(String username) {
        boolean removed = users.removeIf(user -> user.getUsername().equals(username));
        if (removed) {
            saveUsersToFile();
        }
        return removed;
    }

    public boolean updateUser(String role, String username, String password, String firstName, String lastName, String contact, String email) {
        for (User user : users) {
            if (user.getUsername().equals(username) && userRoleMatches(user, role)) {
                user.setPassword(password);
                user.setFName(firstName);
                user.setLName(lastName);
                user.setContact(contact);
                user.setEmail(email);
                saveUsersToFile();
                return true;
            }
        }
        return false; // User not found
    }

    private boolean userRoleMatches(User user, String role) {
        String normalizedRole = role.replaceAll("\\s", "").toLowerCase();
        return user.getClass().getSimpleName().toLowerCase().equals(normalizedRole);
    }

    public void addMenuItem(MenuItem menuItem) {
        menuItems.add(menuItem);
        saveMenuItemsToFile();
    }

    public boolean removeMenuItem(String itemName) {
        boolean removed = menuItems.removeIf(item -> item.getName().equals(itemName));
        if (removed) {
            saveMenuItemsToFile();
        }
        return removed;
    }

    public List<MenuItem> getAllMenuItems() {
        return new ArrayList<>(menuItems);
    }

    public List<User> getAllUsers() {
        return new ArrayList<>(users); // Return a copy of the users list
    }

    void saveUsersToFile() {
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(USERS_FILE)))) {
            for (User user : users) {
                writer.println(user.getClass().getSimpleName() + "," + user.getUsername() + "," + user.getPassword() + "," +
                        user.getFName() + "," + user.getLName() + "," + user.getContact() + "," + user.getEmail());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private List<User> loadUsersFromFile() {
        List<User> userList = new ArrayList<>();
        File file = new File(USERS_FILE);
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(USERS_FILE))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 7) {
                        String role = parts[0];
                        String username = parts[1];
                        String password = parts[2];
                        String fName = parts[3];
                        String lName = parts[4];
                        String contact = parts[5];
                        String email = parts[6];

                        User user = null;
                        switch (role) {
                            case "Administrator":
                                user = new Administrator(username, password, fName, lName, contact, email);
                                break;
                            case "Customer":
                                user = new Customer(username, password, fName, lName, contact, email);
                                break;
                            case "DeliveryRunner":
                                user = new DeliveryRunner(username, password, fName, lName, contact, email);
                                break;
                            case "Vendor":
                                user = new Vendor(username, password, fName, lName, contact, email);
                                break;
                        }
                        if (user != null) {
                            userList.add(user);
                        }
                    }
                }
            } catch (IOException e) {
                // Handle exception
                e.printStackTrace();
            }
        }
        return userList;
    }

    private void saveMenuItemsToFile() {
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(MENU_ITEMS_FILE)))) {
            for (MenuItem menuItem : menuItems) {
                writer.println(menuItem.getName() + "," + menuItem.getPrice() + "," + menuItem.getImagePath());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private List<MenuItem> loadMenuItemsFromFile() {
        List<MenuItem> items = new ArrayList<>();
        File file = new File(MENU_ITEMS_FILE);
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(MENU_ITEMS_FILE))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 3) {
                        String name = parts[0];
                        double price = Double.parseDouble(parts[1]);
                        String imagePath = parts[2];
                        items.add(new MenuItem(name, price, imagePath));
                    }
                }
            } catch (IOException e) {
                // File might not exist or be empty, which is fine
            }
        }
        return items;
    }

    public void topUpCredit(Customer customer, double amount) {
        customer.setCredit(customer.getCredit() + amount);
        saveCreditToFile(customer);
    }

    private void saveCreditToFile(Customer customer) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(customer.getUsername() + "credit.txt"))) {
            writer.write(Double.toString(customer.getCredit()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public double loadCreditFromFile(Customer customer) {
        File file = new File(customer.getUsername() + "credit.txt");
        if (!file.exists()) {
            try {
                file.createNewFile(); // Create the file if it doesn't exist
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                    writer.write("0.0"); // Initialize with zero credit
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return 0.0; // Return zero credit if file didn't exist
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            return Double.parseDouble(reader.readLine());
        } catch (IOException e) {
            e.printStackTrace();
            return 0.0;
        }
    }

    public Customer getCustomerByUsername(String username) {
        for (User user : users) {
            if (user instanceof Customer && user.getUsername().equals(username)) {
                return (Customer) user;
            }
        }
        return null; // Return null if no matching customer is found
    }

    public DeliveryRunner getDeliveryRunnerByUsername(String username) {
    for (User user : users) {
        if (user instanceof DeliveryRunner && user.getUsername().equals(username)) {
            return (DeliveryRunner) user;
        }
    }
    return null; // Return null if no matching delivery runner is found
}
}