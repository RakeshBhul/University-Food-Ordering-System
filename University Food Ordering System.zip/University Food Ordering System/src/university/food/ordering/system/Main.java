package university.food.ordering.system;

import javax.swing.*;
import java.awt.*;
import services.UserService;
import views.LoginView;

public class Main {
    private static UserService userService = new UserService();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Tech University Food Ordering System");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // Create background panel with image
            JPanel backgroundPanel = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    ImageIcon backgroundIcon = new ImageIcon(Main.class.getResource("/images/food2.jpg"));
                    Image backgroundImage = backgroundIcon.getImage();
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            };
            backgroundPanel.setLayout(new GridBagLayout());

            // Welcome Message
            JLabel welcomeLabel = new JLabel("Welcome to Tech University Food Ordering System", SwingConstants.CENTER);
            welcomeLabel.setFont(new Font("Arial", Font.BOLD, 28));
            welcomeLabel.setForeground(Color.GREEN); // White color for better visibility on background
            GridBagConstraints gbcWelcome = new GridBagConstraints();
            gbcWelcome.gridx = 0;
            gbcWelcome.gridy = 0;
            gbcWelcome.gridwidth = 2;
            gbcWelcome.insets = new Insets(20, 20, 20, 20);
            backgroundPanel.add(welcomeLabel, gbcWelcome);

            // Panel for User Role Selection
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(20, 20, 20, 20);
            gbc.fill = GridBagConstraints.HORIZONTAL;

            // Administrator Button
            JButton adminButton = createButton("Administrator", "/images/admin.png", new Color(0x007FFF));
            adminButton.addActionListener(e -> {
                LoginView loginView = new LoginView(userService, "Administrator");
                loginView.setVisible(true);
                frame.dispose();
            });
            gbc.gridx = 0;
            gbc.gridy = 1;
            backgroundPanel.add(adminButton, gbc);

            // Delivery Runner Button
            JButton runnerButton = createButton("Delivery Runner", "/images/delivery.png", new Color(0x28A745));
            runnerButton.addActionListener(e -> {
                LoginView loginView = new LoginView(userService, "Delivery Runner");
                loginView.setVisible(true);
                frame.dispose();
            });
            gbc.gridx = 1;
            backgroundPanel.add(runnerButton, gbc);

            // Customer Button
            JButton customerButton = createButton("Customer", "/images/customer.png", new Color(0xDC3545));
            customerButton.addActionListener(e -> {
                LoginView loginView = new LoginView(userService, "Customer");
                loginView.setVisible(true);
                frame.dispose();
            });
            gbc.gridx = 0;
            gbc.gridy = 2;
            backgroundPanel.add(customerButton, gbc);

            // Vendor Button
            JButton vendorButton = createButton("Vendor", "/images/vendor.png", new Color(0xFFC107));
            vendorButton.addActionListener(e -> {
                LoginView loginView = new LoginView(userService, "Vendor");
                loginView.setVisible(true);
                frame.dispose();
            });
            gbc.gridx = 1;
            backgroundPanel.add(vendorButton, gbc);

            frame.add(backgroundPanel);

            // Set frame properties
            frame.setSize(800, 600);
            frame.setMinimumSize(new Dimension(600, 500));
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    private static JButton createButton(String text, String iconPath, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(backgroundColor);
        button.setIcon(new ImageIcon(Main.class.getResource(iconPath)));
        button.setVerticalTextPosition(SwingConstants.BOTTOM);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setPreferredSize(new Dimension(200, 200));
        button.setToolTipText("Login as " + text);

        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(button.getBackground().darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(backgroundColor);
            }
        });

        return button;
    }
}
