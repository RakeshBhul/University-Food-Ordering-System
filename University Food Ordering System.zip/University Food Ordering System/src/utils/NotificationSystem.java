package services;

import models.DeliveryRunner;
import models.Customer;
import models.MenuItem;
import models.User;

import java.util.List;

public class NotificationSystem {
    private UserService userService;

    public NotificationSystem(UserService userService) {
        this.userService = userService;
    }

    public void sendNotification(String message) {
        List<DeliveryRunner> deliveryRunners = userService.getUsersByRole(DeliveryRunner.class);
        for (DeliveryRunner deliveryRunner : deliveryRunners) {
            System.out.println("Notification to " + deliveryRunner.getUsername() + ": " + message);
        }
    }

    public void notifyDeliveryRunner(MenuItem menuItem) {
        String message = "New order: " + menuItem.getName() + " for $" + menuItem.getPrice();
        sendNotification(message);
    }

    public void sendReceipt(String receipt, Customer customer) {
        // For simplicity, we'll just print the receipt to the console.
        // In a real application, you might send an email or a message through a notification system.
        System.out.println("Sending receipt to " + customer.getUsername() + ":");
        System.out.println(receipt);
    }
}
